package org.example;

public class Carro extends Veiculo{

    @Override
    public double calcularPedagio() {
        return 12.50;
    }

    @Override
    public  double calcularSeguro(){return 880;}

    public Carro(String marca, String modelo) {
        super(marca, modelo);
    }
}
