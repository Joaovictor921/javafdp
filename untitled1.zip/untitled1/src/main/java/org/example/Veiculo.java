package org.example;

public abstract class Veiculo {
    private String marca;
    private String modelo;

    public abstract double calcularPedagio();

    public abstract double calcularSeguro();

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public Veiculo(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }
}
