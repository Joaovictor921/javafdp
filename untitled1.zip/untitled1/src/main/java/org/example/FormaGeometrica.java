package org.example;

public abstract class FormaGeometrica {
    private int altura;
    private int largura;

    public FormaGeometrica(int altura, int largura) {
        this.altura = altura;
        this.largura = largura;
    }

    public abstract double calcularArea();
    public abstract double calcularPerimetro();
}
