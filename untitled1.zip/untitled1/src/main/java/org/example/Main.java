package org.example;




public class Main {
    public static void main(String[] args) {
        //Veiculo vassoura = new Veiculo("Magic", "VS2000");
        Carro gol = new Carro("VW", "Power 1.6");
        Moto adv = new Moto("Honda", "ADV 150" );

        //System.out.printf("%f\n",vassoura.calcularPedagio());
        System.out.printf("%.2f\n",gol.calcularPedagio());
        System.out.printf("%.2f\n\n",adv.calcularPedagio());

        System.out.printf("%.2f\n",gol.calcularSeguro());
        System.out.printf("%.2f\n\n",adv.calcularSeguro());


    }
}