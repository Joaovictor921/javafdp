package org.example;

public class Moto extends Veiculo{
    @Override
    public double calcularPedagio() {
        return 6.00;
    }

    @Override
    public  double calcularSeguro(){return 350;}


    public Moto(String marca, String modelo) {
        super(marca, modelo);
    }
}
